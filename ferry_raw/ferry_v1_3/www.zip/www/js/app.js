// Dom7
var $ = Dom7;

// Theme
var theme = 'auto';
if (document.location.search.indexOf('theme=') >= 0) {
  theme = document.location.search.split('theme=')[1].split('&')[0];
}

// Init App
var app = new Framework7({
  id: 'io.framework7.testapp',
  root: '#app',
  theme: theme,
  data: function () {
    return {
      user: {
        firstName: 'John',
        lastName: 'Doe',
      },
    };
  },
  methods: {
    helloWorld: function () {
      app.dialog.alert('Hello World!');
    },
  },
  routes: routes,
  vi: {
    placementId: 'pltd4o7ibb9rc653x14',
  },
});

$(".balance").each(function() { 
    alert("Your book is overdue"); 
});



$(function(){
  var $refreshButton = $('#refresh');
  var $results = $('#css_result');
  
  function refresh(){
    var css = $('style.cp-pen-styles').text();
    $results.html(css);
  }

  refresh();
  $refreshButton.click(refresh);
  
  // Select all the contents when clicked
  $results.click(function(){
    $(this).select();
  });
});

function signMeOut(){

      my_user_sys_id = "";
      my_e_pass = "";
      my_full_name = "";
      my_phone = "";

      localStorage.removeItem('user_sys_id');
      localStorage.removeItem('e_pass');
      localStorage.removeItem('c_name');
      localStorage.removeItem('c_phone');


}

function checkIfSignedIn(){

    var my_user_sys_id =localStorage.getItem("user_sys_id");
    var my_e_pass =localStorage.getItem("e_pass");
    var my_full_name =localStorage.getItem("c_name");
    var my_phone =localStorage.getItem("c_phone");

    if(my_user_sys_id == null  || my_e_pass == null  || my_full_name == null  || my_phone == null){

          // AUTO SIGN-OUT
          signMeOut();

    } else {


    }

}

function checkLogin() {
    var disUsername = document.getElementById("dis_username").value;
    var disPassword = document.getElementById("dis_password").value;
    var toastBottom = app.toast.create({
  text: 'All Fields Must Be Completed',
  closeTimeout: 2000,
});
        var toastnot = app.toast.create({
  text: 'Account Not Found',
  closeTimeout: 2000,
})


    if(disUsername.trim() == "" || disPassword.trim() == "" ){

    
  toastBottom.open();

    } else if (disUsername.trim() != "" || disPassword.trim() != ""){

      //alert("Validating...");
       var url = "http://valid.fishpott.com/inc/login.php";
       var loginData = {
          curr_username : disUsername,
          curr_password : disPassword
      };

      //var app = new Framework7();

      //var $$ = Dom7;
      app.preloader.show();
      app.request.post(url, loginData, function (response) {

        var loginResponse = JSON.parse(response);



        console.log(loginResponse);

        if(loginResponse["return_status"] == "1"){

          localStorage.setItem("user_sys_id", loginResponse["system_id"]);
          localStorage.setItem("e_pass", loginResponse["e_pass"]);
          localStorage.setItem("c_name", loginResponse["comp_name"]);
          localStorage.setItem("c_phone", loginResponse["signup_phone"]);
          $('#lgr').append('<a id="success_login" style="display : none;" href="/main/">success</a>');

          $('#success_login').click();


        } else {

          toastnot.open();


        }

//router.navigate('/com_index/')
app.preloader.hide();

      });
    } else {

      alert("Something went awry");

    }


}


function checkSignup() {

    var disSignupName = document.getElementById("signup_name").value;
    var disSignupEmail = document.getElementById("signup_email").value;
    var disSignupPassword = document.getElementById("signup_password").value;
    var disSignupPasswordRepeat = document.getElementById("signup_password_repeat").value;

    var toastBottom = app.toast.create({
  text: 'All Fields Must Be Completed',
  closeTimeout: 2000,
});

var toastPasswordsDontMatch = app.toast.create({
  text: 'Passwords do not match',
  closeTimeout: 2000,
});

var toastPasswordsDontMatch = app.toast.create({
  text: 'Something went awry',
  closeTimeout: 2000,
});


    if(disSignupName.trim() == "" || disSignupEmail.trim() == "" || disSignupPassword.trim() != disSignupPasswordRepeat ){

      if(disSignupPassword.trim() != disSignupPasswordRepeat.trim()){
        // PASSWORDS DON'T MATCH
        toastPasswordsDontMatch.open();


      } else {

        toastBottom.open();

      }

    

    } else if (disSignupName.trim() != ""
     && disSignupEmail.trim() != "" && disSignupPassword.trim() != "" 
     && disSignupPasswordRepeat.trim() != "" && disSignupPassword.trim() == disSignupPasswordRepeat.trim()){

      //alert("Validating...");
       var url_real = "http://app.dannydoku.com/inc/signup.php";
       var loginData = {
          signup_name : disSignupName,
          signup_email : disSignupEmail,
          signup_password : disSignupPassword,
      };

      //var app = new Framework7();

      //var $$ = Dom7;
      app.preloader.show();

          
              console.log(loginData);
      app.request({
          url: url_real,
          type: "POST",
          data: loginData,
          success: function(response){
          
              console.log("response : " + response);
              var loginResponse = JSON.parse(response);

              console.log(loginResponse);

              if(loginResponse["status"] == "yes"){

                localStorage.setItem("user_sys_id", loginResponse["system_id"]);
                localStorage.setItem("e_pass", loginResponse["key"]);
                localStorage.setItem("c_name", loginResponse["signup_name"]);
                localStorage.setItem("c_phone", loginResponse["signup_phone"]);
                $('#next_step').append('<a id="success_signup" style="display : none;" href="/main/">success</a>');

                app.preloader.hide();
                $('#success_signup').click();


              } else {

                alert(loginResponse["error"]);


              }

          },

          error: function(XMLHttpRequest, textStatus, errorThrown) {
    
        addEmpRequestToggle = 0;

              console.log("Something went awry");
              app.preloader.hide();
          }
        });


      /*
      app.request.post(url, loginData, function (response) {

        console.log("response : " + response);
        var loginResponse = JSON.parse(response);

        console.log(loginResponse);

        if(loginResponse["status"] == "yes"){

          localStorage.setItem("user_sys_id", loginResponse["system_id"]);
          localStorage.setItem("e_pass", loginResponse["key"]);
          localStorage.setItem("c_name", loginResponse["signup_name"]);
          $('#next_step').append('<a id="success_signup" href="/main/">success</a>');

          $('#success_signup').click();


        } else {

          alert(loginResponse["error"]);


        }

//router.navigate('/com_index/')
app.preloader.hide();

      });
      */
    } else {

      alert("Something went awry");

    }


}




/*********************************************************************************************************************************

                                                                  FUNCTIONS END 

 /******************************************************************************************************************************/

